package com.fahmi.semua_data_dan_model

data class FahmiUserFahmi(
    val login: String?,
    val id: Int,
    val avatar_url: String?
)
