package com.fahmi.semua_data_dan_model

import com.fahmi.semua_data_dan_model.FahmiUserFahmi

data class FahmiUserResponseFahmi(

    val items : ArrayList<FahmiUserFahmi>
)
