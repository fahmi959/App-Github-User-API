package com.fahmi.semua_data_dan_model

data class PengingatApkFahmi(
    var isReminded: Boolean = false

)
